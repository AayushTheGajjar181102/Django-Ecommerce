from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from .views import *

urlpatterns = [
    
    path('home', home, name='home'),
    
    path('products', products, name='products'),
    path('products/<category>', category_products, name='category_products'),
    path('products-filler', price_products, name='price_products'),
    path('product-detail/<id>', product_detail, name='product_detail'),
    
    path('contact', contact, name='contact'),
    
    path('login', user_login, name='login'),
    path('signup', user_signup, name='signup'),
    path('logout', user_logout, name='logout'),
    
    path('cart', cart, name='cart'),
    path('cart-process/<id>', cart_process, name='cart_process'),
    path('cart-delete/<id>', cart_delete, name='cart_delete'),
    path('cart-product-payment/<id>/<int:quantity>/<payment>', cart_product_payment, name='cart_product_payment'),
    
    path('wishlist', wishlist, name='wishlist'),
    path('wishlist-process/<id>', wishlist_process, name='wishlist_process'),
    path('wishlist-delete/<id>', wishlist_delete, name='wishlist_delete'),
    
    path('review/<id>', review, name='review'),
    
    path('my-orders', orders, name='my_orders'),
    path('my-order-cencel/<id>', order_cancel, name='my_order_cancel'),
    
    path('my-order-details/<id>', order_details, name='my_order_details'),
    path('my-order-detail-cencel/<id>', order_detail_cancel, name='my_order_detail_cancel'),
    
    path('checkout', checkout, name='checkout'),
    
    path('invoice/<id>', invoice, name="invoice"),
    
    path('account', account, name='account'),
    path('feedback', feedback, name='feedback'),
    
    path('chatbot', chatbot, name='chatbot')
    
] + static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)
