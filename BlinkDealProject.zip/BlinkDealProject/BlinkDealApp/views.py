from django.shortcuts import render, redirect
from django.contrib import messages
from django.conf import settings
from django.db.models import Q
from BlinkDeal.models import *
from django.core import mail
import itertools as itt
from .pdf_config import *
from .models import *
import razorpay
import math

# Create your views here.

####################################################################################################################################################################################
# GET QUERY FROM REQUEST.POST

def postquery(post, files=None, objects=None):
    data = {}   

    # print(objects)
    # print(type(objects))
    
    for column in post:
        value = post.get(column)
        
        # print(column, value)
        
        if value.isnumeric():
            data.update({f'{column}': float(value)})
            
        elif 'object' in value and objects is not None:
            
            if type(objects) is not list:
                for object in objects:
                    if str(object) == value:
                        data.update({f'{column}': object})
                        break
            else:
                objsbreak = False
                for classes in objects:
                    
                    if objsbreak:
                        break
                    
                    for object in classes:
                        if str(object) == value:
                            data.update({f'{column}': object})
                            objsbreak = True
                            break
        else: 
            data.update({f'{column}': f'{value}'}) 
        
    if files is not None:
        for file in files:
            data.update({f'{file}': files.get(file)}) 
       
    return dict(itt.islice(data.items(), 1, None))

####################################################################################################################################################################################

def home(request):
    
    if Category.objects.exists() and Product.objects.exists():
        categories = Category.objects.all()
        products = Product.objects.all()
        return render(request, 'user_panel/index.html', {"categories":categories, "products": products})
    else:
        return render(request, 'user_panel/index.html', {"categories":[], "products": []})


####################################################################################################################################################################################
# PRODUCT

def products(request):
    
        products = Product.objects.all()
        categories = Category.objects.all()
        
        if request.GET.get('search'):
            
            products = products.filter(
                Q(category__category_name__icontains = request.GET.get('search')) |
                Q(product_name__icontains = request.GET.get('search'))
            )
        
        return render(request, 'user_panel/product/products.html', {"products": products, "categories": categories})
    
def category_products(request, category):
    
    if 'user_name' in request.COOKIES and request.session.has_key('user_name'):
        products = Product.objects.filter(category__category_name = category)
        categories = Category.objects.all()
        return render(request, 'user_panel/product/products.html', {"products": products, "categories": categories})
    else:
        return redirect(user_login)
    

def price_products(request):
    
    if 'user_name' in request.COOKIES and request.session.has_key('user_name'):
        
        if request.method == "POST":
            products = Product.objects.filter(product_price__lte = request.POST['high'], product_price__gte = request.POST['low'])    
            categories = Category.objects.all()
            return render(request, 'user_panel/product/products.html', {"products": products, "categories": categories})
        else:
            return redirect(products)
    else:
        return redirect(user_login)

def product_detail(request, id):
        product = Product.objects.filter(id = id)
        reviews = Review.objects.all()
        return render(request, 'user_panel/product/product-detail.html', {"product": product, "reviews":reviews})    
    
####################################################################################################################################################################################
#CONTACT

def contact(request):
    return render(request, 'user_panel/contact.html')

####################################################################################################################################################################################
# USER

def user_login(request):
    
    if request.method == "POST":
        
        if User.objects.filter(user_email = request.POST['user_email']):
            user = User.objects.filter(user_email = request.POST['user_email'], user_password = request.POST['user_password'])
            
            if user:
                messages.success(request, "Login Successfully")
                request.session['user_name'] = user[0].user_name
                request.session['user_email'] = user[0].user_email
                
                response = redirect(user_login)
                response.set_cookie('user_name', user[0].user_name)
                response.set_cookie('user_email', user[0].user_email)
                return response
            else:
                messages.error(request, "Login Failed")
                return redirect(user_login)
        else:
            messages.error(request, "User not exists")
            return redirect(user_signup)
            
    return render(request, 'user_panel/user/login.html')

def user_signup(request):
    
    if request.method == "POST":
        
        if not(
            User.objects.filter(user_email = request.POST['user_email']) 
            and User.objects.filter(user_mobile = request.POST['user_mobile']) 
            and User.objects.filter(User.objects.filter(user_password = request.POST['user_password']))):
            
            if User.objects.create(**postquery(request.POST)):
                messages.success(request, "Signup Successfully")
            else:
                messages.error(request, "Signup Failed")
        else:
            messages.error(request, "User already exists")
            return redirect(user_login)
            
        return redirect(user_signup)
    
    return render(request, 'user_panel/user/signup.html')

def user_logout(request):
    
    if 'user_name' in request.COOKIES and request.session.has_key('user_name'):
        del request.session['user_name']
        del request.session['user_email']
        response = redirect(user_login)
        response.delete_cookie('user_name')
        response.delete_cookie('user_email')
        return response
    
####################################################################################################################################################################################
# WISHLIST

def wishlist(request):
    
    if 'user_name' in request.COOKIES and request.session.has_key('user_name'):
        
        if Wishlist.objects.exists():
            wishlists = Wishlist.objects.filter(user__user_email = request.session['user_email'])
            return render(request, "user_panel/wishlist.html", {"wishlists": wishlists})
        else:
            return render(request, "user_panel/wishlist.html", {"wishlists": []})
    else:
        return redirect(user_login)
    
def wishlist_process(request, id):
    
    if 'user_name' in request.COOKIES and request.session.has_key('user_name'):
        
        if not Wishlist.objects.filter(product__id = id, user__user_email = request.session['user_email']):
            product = Product.objects.filter(id = id)
            user = User.objects.filter(user_name = request.session['user_name'])
            Wishlist.objects.create(product = product[0], user = user[0])
            
        return redirect(wishlist)
    else:
        return redirect(user_login)
    
def wishlist_delete(request, id):
    
    if 'user_name' in request.COOKIES and request.session.has_key('user_name'):
        wishlist_object = Wishlist.objects.filter(id = id)
        
        if wishlist_object:
            wishlist_object.delete()
        
        return redirect(wishlist)
    
    else:
        return redirect(user_login)

####################################################################################################################################################################################
# CART
 
def cart(request):
    
    if 'user_name' in request.COOKIES and request.session.has_key('user_name'):
        
        if ShoppingCart.objects.exists():
            carts = ShoppingCart.objects.filter(user__user_email = request.session['user_email'])
            return render(request, "user_panel/cart.html", {"carts":carts})
        else:
            return render(request, "user_panel/cart.html", {"carts":[]})
    else:
        return redirect(user_login)
    
def cart_process(request, id):
    
    if 'user_name' in request.COOKIES and request.session.has_key('user_name'):
         
        if request.method == "POST":
            print(id)

        elif not ShoppingCart.objects.filter(product__id = id, user__user_email = request.session['user_email']):
            product = Product.objects.filter(id = id)
            user = User.objects.filter(user_name = request.session['user_name'])
            ShoppingCart.objects.create(product = product[0], user = user[0], product_payment = product[0].product_price)
            
        return redirect(cart)
    else:
        return redirect(user_login)

def cart_product_payment(request, id, quantity, payment):
    
    if request.method == "POST" and ShoppingCart.objects.filter(id = id):
        
        print(id, quantity, payment)
        cart_object = ShoppingCart.objects.filter(id = id)
        cart_object.update(product_payment = payment, product_quantity = quantity)
        
    return redirect(cart)
        
def cart_delete(request, id):
    
    if 'user_name' in request.COOKIES and request.session.has_key('user_name'):
        cart_object = ShoppingCart.objects.filter(id = id)
    
        if cart_object:
            cart_object.delete()
        
        return redirect(cart)
    
    else:
        return redirect(user_login)
    

####################################################################################################################################################################################
# REVIEW

def review(request, id):
    
    if 'user_name' in request.COOKIES and request.session.has_key('user_name'):
        
        product = Product.objects.filter(id = id)
        user = User.objects.filter(user_email = request.session['user_email'])
        
        if request.method == "POST":
            
            review_object = Review.objects.filter(user__user_email = request.session['user_email'])
            
            if not review_object:
                Review.objects.create(**postquery(request.POST), product=product[0], user=user[0])
            else:
                review_object.update(**postquery(request.POST), product=product[0], user=user[0])
                
        return redirect(product_detail, id)
            
    else:
        return redirect(user_login)

####################################################################################################################################################################################
#MY ORDERS

def orders(request):
    
    if 'user_name' in request.COOKIES and request.session.has_key('user_name'):
        
        if Order.objects.exists():
            orders = Order.objects.filter(user__user_email = request.session['user_email'])
            return render(request, "user_panel/order/my_orders.html", {"orders": orders})
        else:
            return render(request, "user_panel/order/my_orders.html", {"orders": []})
    else:
        return redirect(user_login)

def order_cancel(request, id): 
    if 'user_name' in request.COOKIES and request.session.has_key('user_name'):
        
        order_object = Order.objects.filter(id = id)
        
        if order_object:
            order_object.update(status = "Canceled")
            
            order_details = OrderDetails.objects.filter(order = order_object[0])
            order_details.update(status = "Canceled")
            
            for order_detail in order_details:
                product = Product.objects.get(id = order_detail.product.id)
                product.product_quantity += order_detail.quantity
                product.save()
        
        return redirect(orders)
    
    else:
        return redirect(user_login)
    
####################################################################################################################################################################################
#MY ORDER DETAILS

def order_details(request, id):
    
    if 'user_name' in request.COOKIES and request.session.has_key('user_name'):
        
        if OrderDetails.objects.exists():
            order_details = OrderDetails.objects.filter(order__id = id, order__user__user_email = request.session['user_email'])
            print(order_details)
            return render(request, "user_panel/order/order_details.html", {"order_details": order_details})
        else:
            return render(request, "user_panel/order/order_details.html", {"order_details": []})
    else:
        return redirect(user_login)

def order_detail_cancel(request, id): 
    if 'user_name' in request.COOKIES and request.session.has_key('user_name'):
         
        order_object = OrderDetails.objects.filter(id = id)
        
        if order_object:
            order_object.update(status = "Canceled")
            product = Product.objects.get(id = order_object[0].product.id)
            product.product_quantity += order_object[0].quantity
            product.save()
        
        if OrderDetails.objects.filter(order__id = order_object[0].order.id, status="Canceled"):
            order = Order.objects.get(id = order_object[0].order.id)
            order.status = "Canceled"
            order.save()
            
        return redirect(orders)
    
    else:
        return redirect(user_login)

####################################################################################################################################################################################
#CHECKOUT

def checkout(request):
    
    if 'user_name' in request.COOKIES and request.session.has_key('user_name'):
        
        if request.method == "POST":  
            
            print("INSIDE POST CHECKPUT")
            print(request.POST)

            users = User.objects.all()
            order_object = Order.objects.create(**postquery(request.POST, None, users))
            
            if request.POST['payment_method'] == "Online":
                client = razorpay.Client(auth=(settings.RAZORPAY_ID, settings.RAZORPAY_SECRET))
                payment = client.order.fetch(request.POST['razorpay_order_id'])

                print(payment['amount_due'])
                
                if payment['amount_due'] == 0:
                    order_object.is_paid = True
                    order_object.save()

                
            carts = ShoppingCart.objects.filter(user__user_email = request.session['user_email'])   
            
            for cart_item in carts:
                OrderDetails.objects.create(order = order_object, product = cart_item.product, quantity = cart_item.product_quantity, order_price = cart_item.product_payment)
                product = Product.objects.get(id = cart_item.product.id)
                product.product_quantity -= cart_item.product_quantity
                product.save()
            
            ShoppingCart.objects.filter(user__user_email = request.session['user_email']).delete()
            
            # order = Order.objects.filter(id = order_object.id)
            # orderdetails = OrderDetails.objects.filter(id = order_object.id)
            # attach_message = save_pdf({"order":order, "orderdetails": orderdetails})
            # print(attach_message)
            
            subject = "DailyShop Order"
            user_name = request.session['user_name']
            message = f'Dear {user_name}, your order is successfully accepted. \n Thank You, \n Visit Again @ dailyshop.com. \n'
            recipient_list = [request.session['user_email'],]
            from_email = settings.EMAIL_HOST_USER
            mail.send_mail(subject, message, from_email, recipient_list)
            
            return redirect(orders)
        
        if ShoppingCart.objects.exists():
            
            total_payment = 0
            
            carts = ShoppingCart.objects.filter(user__user_email = request.session['user_email'])
            user = User.objects.filter(user_email = request.session['user_email'])
        
            for cart_object in carts.values():
                total_payment += int(cart_object['product_payment'])
            total_payment += int(math.trunc(round(total_payment*18/100)))
           
            print(total_payment)
            
            if total_payment < 1:
                return redirect(cart)
            
            client = razorpay.Client(auth=(settings.RAZORPAY_ID, settings.RAZORPAY_SECRET))
            data = {"amount": total_payment*100, "currency": "INR", "payment_capture": 1}
            payment = client.order.create(data=data)
            
            return render(request, "user_panel/checkout.html", {"carts": carts, "user": user, "payment":payment})
        else:
            return redirect(cart)
    else:
        return redirect(user_login)
 
####################################################################################################################################################################################
#INVOICE

def invoice(request, id):
    if 'user_name' in request.COOKIES and request.session.has_key('user_name'):
        order = Order.objects.filter(id = id)
        orderdetails = OrderDetails.objects.filter(order__id = id)
        return render(request, 'user_panel/invoice/invoice.html', {"order": order, "orderdetails": orderdetails})
    else:
        return redirect(user_login)
    
####################################################################################################################################################################################
#ACCOUNT

def account(request):
    
    if 'user_name' in request.COOKIES and request.session.has_key('user_name'):
        
        user = User.objects.filter(user_email = request.session['user_email'])
        
        if request.method == "POST":
            user.update(**postquery(request.POST))
            request.session['user_email'] = request.POST['user_email']
            return redirect(account)

        if user:
            return render(request, 'user_panel/account.html', {"user":user})
        else:
            return render(request, 'user_panel/account.html', {"user":[]})
    else:
        return redirect(user_login)

####################################################################################################################################################################################
#FEEDBACK

def feedback(request):
    
    if 'user_name' in request.COOKIES and request.session.has_key('user_name'):
        
        if request.method == "POST" :
            
            user = User.objects.filter(user_email = request.session['user_email'])
            
            print(postquery(request.POST))
            
            if user:
                Feedback.objects.create(**postquery(request.POST), user=user[0])
                messages.success(request, "Feedback Submitted Successfully")        
            else:
                messages.error(request, "Feedback Not Submitted")
                
            return redirect(feedback)
            
        return render(request, 'user_panel/feedback.html')
    else:
        return redirect(user_login)
  
    
####################################################################################################################################################################################
#CHATBOT

def chatbot(request):
    return render(request, "user_panel/chatbot/chatbot.html")