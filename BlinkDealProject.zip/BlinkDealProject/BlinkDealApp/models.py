from django.db import models
from django.core import validators
from BlinkDeal.models import *
# Create your models here.
    
class ShoppingCart(models.Model):
    product_quantity = models.IntegerField(default=1, null=True)
    product_payment = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    
class Wishlist(models.Model):
    stock_status = models.BooleanField(default=True)
    add_to_cart = models.BooleanField(default=False)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    

class Review(models.Model):
    first_date = models.DateField(auto_now_add=True)
    last_updated_date = models.DateField(auto_now=True)
    details = models.TextField()
    
    rating = models.IntegerField(
        validators= [
            validators.MinValueValidator(0),
            validators.MaxValueValidator(5)
        ]
    )
    
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    