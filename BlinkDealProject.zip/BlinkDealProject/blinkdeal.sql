-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 18, 2024 at 06:25 PM
-- Server version: 8.0.37-0ubuntu0.20.04.3
-- PHP Version: 7.4.3-4ubuntu2.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blinkdeal`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add admin', 7, 'add_admin'),
(26, 'Can change admin', 7, 'change_admin'),
(27, 'Can delete admin', 7, 'delete_admin'),
(28, 'Can view admin', 7, 'view_admin'),
(29, 'Can add category', 8, 'add_category'),
(30, 'Can change category', 8, 'change_category'),
(31, 'Can delete category', 8, 'delete_category'),
(32, 'Can view category', 8, 'view_category'),
(33, 'Can add contact', 9, 'add_contact'),
(34, 'Can change contact', 9, 'change_contact'),
(35, 'Can delete contact', 9, 'delete_contact'),
(36, 'Can view contact', 9, 'view_contact'),
(37, 'Can add order', 10, 'add_order'),
(38, 'Can change order', 10, 'change_order'),
(39, 'Can delete order', 10, 'delete_order'),
(40, 'Can view order', 10, 'view_order'),
(41, 'Can add user', 11, 'add_user'),
(42, 'Can change user', 11, 'change_user'),
(43, 'Can delete user', 11, 'delete_user'),
(44, 'Can view user', 11, 'view_user'),
(45, 'Can add product', 12, 'add_product'),
(46, 'Can change product', 12, 'change_product'),
(47, 'Can delete product', 12, 'delete_product'),
(48, 'Can view product', 12, 'view_product'),
(49, 'Can add order details', 13, 'add_orderdetails'),
(50, 'Can change order details', 13, 'change_orderdetails'),
(51, 'Can delete order details', 13, 'delete_orderdetails'),
(52, 'Can view order details', 13, 'view_orderdetails'),
(53, 'Can add feedback', 14, 'add_feedback'),
(54, 'Can change feedback', 14, 'change_feedback'),
(55, 'Can delete feedback', 14, 'delete_feedback'),
(56, 'Can view feedback', 14, 'view_feedback');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` bigint NOT NULL,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint NOT NULL,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `BlinkDeal_admin`
--

CREATE TABLE `BlinkDeal_admin` (
  `id` bigint NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `admin_email` varchar(254) NOT NULL,
  `admin_password` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `BlinkDeal_admin`
--

INSERT INTO `BlinkDeal_admin` (`id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(3, 'Aaryan Makwana', 'aaryan@gmail.com', 'Aaryan123#');

-- --------------------------------------------------------

--
-- Table structure for table `BlinkDeal_category`
--

CREATE TABLE `BlinkDeal_category` (
  `id` bigint NOT NULL,
  `category_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `BlinkDeal_category`
--

INSERT INTO `BlinkDeal_category` (`id`, `category_name`) VALUES
(1, 'Shoes'),
(2, 'Mobiles'),
(3, 'Shirts'),
(4, 'T-Shirts'),
(5, 'Jeans');

-- --------------------------------------------------------

--
-- Table structure for table `BlinkDeal_contact`
--

CREATE TABLE `BlinkDeal_contact` (
  `id` bigint NOT NULL,
  `contact_name` varchar(50) NOT NULL,
  `contact_subject` varchar(400) NOT NULL,
  `contact_detail` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `BlinkDeal_feedback`
--

CREATE TABLE `BlinkDeal_feedback` (
  `id` bigint NOT NULL,
  `feedback_date` date NOT NULL,
  `feedback_details` longtext NOT NULL,
  `user_id` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `BlinkDeal_order`
--

CREATE TABLE `BlinkDeal_order` (
  `id` bigint NOT NULL,
  `order_date` date NOT NULL,
  `shipping_name` varchar(100) NOT NULL,
  `shipping_mobile` decimal(10,0) NOT NULL,
  `shipping_address` longtext,
  `user_id` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `BlinkDeal_order`
--

INSERT INTO `BlinkDeal_order` (`id`, `order_date`, `shipping_name`, `shipping_mobile`, `shipping_address`, `user_id`) VALUES
(1, '2024-06-17', 'Abhinandan', '9876543981', 'B-1004, POPULAR FLATS, GOTA, AHMEDABAD', 1);

-- --------------------------------------------------------

--
-- Table structure for table `BlinkDeal_orderdetails`
--

CREATE TABLE `BlinkDeal_orderdetails` (
  `id` bigint NOT NULL,
  `quantity` int NOT NULL,
  `order_price` decimal(10,2) NOT NULL,
  `order_id` bigint NOT NULL,
  `product_id` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `BlinkDeal_product`
--

CREATE TABLE `BlinkDeal_product` (
  `id` bigint NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_detail` longtext NOT NULL,
  `product_price` decimal(10,2) NOT NULL,
  `product_image` varchar(100) NOT NULL,
  `category_id` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `BlinkDeal_product`
--

INSERT INTO `BlinkDeal_product` (`id`, `product_name`, `product_detail`, `product_price`, `product_image`, `category_id`) VALUES
(1, 'Adidas Samba', 'Adidas Samba is an athletic shoe manufactured by German multinational Adidas. It was designed by Adidas Founder Adolf Dassler in 1949.[1] It is the second-highest selling Adidas design with over 35 million pairs sold.', '6799.00', 'static/images/adidas_samba_f9SBFqE.jpeg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `BlinkDeal_user`
--

CREATE TABLE `BlinkDeal_user` (
  `id` bigint NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_gender` varchar(10) NOT NULL,
  `user_email` varchar(254) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  `user_mobile` decimal(10,0) NOT NULL,
  `user_address` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `BlinkDeal_user`
--

INSERT INTO `BlinkDeal_user` (`id`, `user_name`, `user_gender`, `user_email`, `user_password`, `user_mobile`, `user_address`) VALUES
(1, 'Aayush Gajjar', 'Male', 'aayush.naval1207@gmail.com', 'Aayush123#', '8200341894', 'B-1004, POPULAR FLATS, GOTA, AHMEDABAD');

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint UNSIGNED NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL
) ;

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(7, 'BlinkDeal', 'admin'),
(8, 'BlinkDeal', 'category'),
(9, 'BlinkDeal', 'contact'),
(14, 'BlinkDeal', 'feedback'),
(10, 'BlinkDeal', 'order'),
(13, 'BlinkDeal', 'orderdetails'),
(12, 'BlinkDeal', 'product'),
(11, 'BlinkDeal', 'user'),
(5, 'contenttypes', 'contenttype'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(22, 'BlinkDeal', '0001_initial', '2024-06-18 08:36:37.235183'),
(23, 'contenttypes', '0001_initial', '2024-06-18 08:36:38.048354'),
(24, 'auth', '0001_initial', '2024-06-18 08:36:48.266961'),
(25, 'admin', '0001_initial', '2024-06-18 08:36:50.704758'),
(26, 'admin', '0002_logentry_remove_auto_add', '2024-06-18 08:36:50.781312'),
(27, 'admin', '0003_logentry_add_action_flag_choices', '2024-06-18 08:36:50.841910'),
(28, 'contenttypes', '0002_remove_content_type_name', '2024-06-18 08:36:51.880591'),
(29, 'auth', '0002_alter_permission_name_max_length', '2024-06-18 08:36:53.151545'),
(30, 'auth', '0003_alter_user_email_max_length', '2024-06-18 08:36:53.330429'),
(31, 'auth', '0004_alter_user_username_opts', '2024-06-18 08:36:53.418641'),
(32, 'auth', '0005_alter_user_last_login_null', '2024-06-18 08:36:54.093034'),
(33, 'auth', '0006_require_contenttypes_0002', '2024-06-18 08:36:54.157590'),
(34, 'auth', '0007_alter_validators_add_error_messages', '2024-06-18 08:36:54.297711'),
(35, 'auth', '0008_alter_user_username_max_length', '2024-06-18 08:36:55.225065'),
(36, 'auth', '0009_alter_user_last_name_max_length', '2024-06-18 08:36:56.296284'),
(37, 'auth', '0010_alter_group_name_max_length', '2024-06-18 08:36:56.511384'),
(38, 'auth', '0011_update_proxy_permissions', '2024-06-18 08:36:56.583994'),
(39, 'auth', '0012_alter_user_first_name_max_length', '2024-06-18 08:36:57.680288'),
(40, 'sessions', '0001_initial', '2024-06-18 08:36:58.290655');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('o3ntqmr2yuq74mnr566xqdvcesda6ta5', '.eJyrVkpMyc3Miy9ILC4uzy9KUbJSSkwsqkzMc0jPTczM0UvOz1XSgarJS8xNBco7guUVfBOzyxPzEuGyqSD12LTXAgATpCON:1sJXxB:AVUg4xGTNdykayPistZPRhSdZ9bt0JSu0cRg9jhKR6M', '2024-07-02 12:28:49.882864');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `BlinkDeal_admin`
--
ALTER TABLE `BlinkDeal_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `BlinkDeal_category`
--
ALTER TABLE `BlinkDeal_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `BlinkDeal_contact`
--
ALTER TABLE `BlinkDeal_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `BlinkDeal_feedback`
--
ALTER TABLE `BlinkDeal_feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `BlinkDeal_feedback_user_id_1f04361c_fk_BlinkDeal_user_id` (`user_id`);

--
-- Indexes for table `BlinkDeal_order`
--
ALTER TABLE `BlinkDeal_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `BlinkDeal_order_user_id_16976da6_fk_BlinkDeal_user_id` (`user_id`);

--
-- Indexes for table `BlinkDeal_orderdetails`
--
ALTER TABLE `BlinkDeal_orderdetails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `BlinkDeal_orderdetails_order_id_2b37dda9_fk_BlinkDeal_order_id` (`order_id`),
  ADD KEY `BlinkDeal_orderdetai_product_id_e2c98694_fk_BlinkDeal` (`product_id`);

--
-- Indexes for table `BlinkDeal_product`
--
ALTER TABLE `BlinkDeal_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `BlinkDeal_product_category_id_33ec8017_fk_BlinkDeal_category_id` (`category_id`);

--
-- Indexes for table `BlinkDeal_user`
--
ALTER TABLE `BlinkDeal_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `BlinkDeal_admin`
--
ALTER TABLE `BlinkDeal_admin`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `BlinkDeal_category`
--
ALTER TABLE `BlinkDeal_category`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `BlinkDeal_contact`
--
ALTER TABLE `BlinkDeal_contact`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `BlinkDeal_feedback`
--
ALTER TABLE `BlinkDeal_feedback`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `BlinkDeal_order`
--
ALTER TABLE `BlinkDeal_order`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `BlinkDeal_orderdetails`
--
ALTER TABLE `BlinkDeal_orderdetails`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `BlinkDeal_product`
--
ALTER TABLE `BlinkDeal_product`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `BlinkDeal_user`
--
ALTER TABLE `BlinkDeal_user`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `BlinkDeal_feedback`
--
ALTER TABLE `BlinkDeal_feedback`
  ADD CONSTRAINT `BlinkDeal_feedback_user_id_1f04361c_fk_BlinkDeal_user_id` FOREIGN KEY (`user_id`) REFERENCES `BlinkDeal_user` (`id`);

--
-- Constraints for table `BlinkDeal_order`
--
ALTER TABLE `BlinkDeal_order`
  ADD CONSTRAINT `BlinkDeal_order_user_id_16976da6_fk_BlinkDeal_user_id` FOREIGN KEY (`user_id`) REFERENCES `BlinkDeal_user` (`id`);

--
-- Constraints for table `BlinkDeal_orderdetails`
--
ALTER TABLE `BlinkDeal_orderdetails`
  ADD CONSTRAINT `BlinkDeal_orderdetai_product_id_e2c98694_fk_BlinkDeal` FOREIGN KEY (`product_id`) REFERENCES `BlinkDeal_product` (`id`),
  ADD CONSTRAINT `BlinkDeal_orderdetails_order_id_2b37dda9_fk_BlinkDeal_order_id` FOREIGN KEY (`order_id`) REFERENCES `BlinkDeal_order` (`id`);

--
-- Constraints for table `BlinkDeal_product`
--
ALTER TABLE `BlinkDeal_product`
  ADD CONSTRAINT `BlinkDeal_product_category_id_33ec8017_fk_BlinkDeal_category_id` FOREIGN KEY (`category_id`) REFERENCES `BlinkDeal_category` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
