from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.db.models import *
from django.conf import settings
from .models import *
import itertools as itt
from datetime import datetime as dt
from django.contrib import messages
from BlinkDealApp.models import *
from re import match

# Create your views here.

####################################################################################################################################################################################
# GET QUERY FROM REQUEST.POST
    
def postquery(post, files=None, objects=None):
    data = {}   

    # print(objects)
    # print(type(objects))
    
    for column in post:
        value = post.get(column)
        
        # print(column, value)
        
        if value.isnumeric():
            data.update({f'{column}': float(value)})
            
        elif 'object' in value and objects is not None:
            
            if type(objects) is not list:
                for object in objects:
                    if str(object) == value:
                        data.update({f'{column}': object})
                        break
            else:
                objsbreak = False
                for classes in objects:
                    
                    if objsbreak:
                        break
                    
                    for object in classes:
                        if str(object) == value:
                            data.update({f'{column}': object})
                            objsbreak = True
                            break
        else: 
            data.update({f'{column}': f'{value}'}) 
        
    if files is not None:
        for file in files:
            data.update({f'{file}': files.get(file)}) 
       
    return dict(itt.islice(data.items(), 1, None))

####################################################################################################################################################################################
# DASHBOARD TABLE
def form(request):
    return redirect(dashboard)

def dashboard(request):

    if "admin_name" in request.COOKIES and request.session.has_key('admin_name'):
        
        users, orders, products, top_products, feedbacks, reviews, todos, revenue = [list(),list(), list(), list(), list(), list(), list(), list()]
        
        if User.objects.exists():
            users = User.objects.all()
        
        if Order.objects.exists():
            revenue = Order.objects.aggregate(Sum('payment_before_tax'), Sum('payment_tax'))
            orders = Order.objects.all()
            
        if Product.objects.exists():
            products = Product.objects.all()
        
        if OrderDetails.objects.exists():
           top_products = OrderDetails.objects.values('product').annotate(Count('product')).order_by('-product__count')[:3]
           recent_products = OrderDetails.objects.all().order_by("-id")[:5]
           
        
        if Feedback.objects.exists():
            feedbacks = Feedback.objects.all()
            recent_feedbacks = Feedback.objects.all().order_by('-id')[:5]
            
        if Review.objects.exists():
            reviews = Review.objects.all()
            recent_reviews = Review.objects.all().order_by("-id")[:5]
        
        if Todo.objects.exists():
            todos = Todo.objects.all()
        
        if request.method == "POST":
            admin = Admin.objects.get(admin_email = request.session['admin_email'])
            Todo.objects.create(task = request.POST['task'], admin = admin)
            return redirect(dashboard)
        
        context = {'users': users, 'products': products, 'orders': orders, 'feedbacks': feedbacks, 'recent_feedbacks': recent_feedbacks, 'reviews': reviews, 'recent_reviews': recent_reviews, 'todos': todos,'revenue': revenue, 'top_products' : top_products, 'recent_products': recent_products}
        
        return render(request, "admin_panel/dashboard.html", context)
    else:
        return redirect(admin_login)

def dashboard_update(request, id, status):
    
    if "admin_name" in request.COOKIES and request.session.has_key('admin_name'):
        
        if request.method == "POST":
            todo = Todo.objects.filter(id = id)
            todo.update(status = status)
        return redirect(dashboard)
    else:
        return redirect(admin_login)
    
def dashboard_delete(request, id):
    
    if "admin_name" in request.COOKIES and request.session.has_key('admin_name'):
        
        Todo.objects.filter(id = id).delete()
        return redirect(dashboard)
    else:
        return redirect(admin_login)
    
#################################################################################################################################
# ADMIN TABLE

def admin_signup(request):
    
    if request.method == "POST":
        
        if not Admin.objects.filter(admin_email = request.POST.get("admin_email")):
            Admin.objects.create(**postquery(request.POST))
        return redirect(admin_signup)
    
    return render(request, "admin_panel/admin/admin-signup.html")


def admin_update(request, id):
    
    dataset = Admin.objects.filter(id = id)
    
    if request.method == "POST":
        dataset.update(**postquery(request.POST))
        return redirect(admins_display)
       
    return render(request, "admin_panel/admin/update-profile.html", {"data": dataset})


def admin_delete(request, id):
    dataset = Admin.objects.filter(id = id)
    
    if dataset is not None:
        dataset.delete()
        
    return redirect(admins_display)
     
       
def admins_display(request):
    
    if "admin_name" in request.COOKIES and request.session.has_key('admin_name'):
        dataset = {}
        
        if Category.objects.exists():
            dataset = Admin.objects.all()
            
        return render(request, "admin_panel/admin/profiles.html", {"data": dataset.values()})
    else:
        return redirect(admin_login)

def admin_login(request):
    
    if request.method == "POST":
        admin = Admin.objects.filter(admin_email = request.POST['admin_email'], admin_password = request.POST['admin_password'])
        
        if admin:
            messages.success(request, "Login Successfullly")
            request.session['admin_name'] = admin[0].admin_name
            request.session['admin_email'] = admin[0].admin_email
            response = redirect(admin_login)
            response.set_cookie('admin_name', admin[0].admin_name)
            response.set_cookie('admin_email', admin[0].admin_email)
            return response
        else:
            messages.error(request, "Login Failed")
        
    return render(request, "admin_panel/admin/admin-login.html")

def admin_change_password(request):
    
    if request.method == "POST":
        admin = Admin.objects.filter(admin_password = request.POST['admin_password'])
        password = request.POST['new_password']
        
        if admin and password == request.POST['confirm_password']:
            
            admin.update(admin_password = password)
            messages.success(request, "Admin Password Changed Successfully")
            return redirect(admin_change_password)
        else:
            messages.error(request, "Invalid Password or Password not Matched")
            return redirect(admin_change_password)
    
    if "admin_name" in request.COOKIES and request.session.has_key('admin_name'): 
        return render(request, "admin_panel/admin/change-password.html")
    else:
        return redirect(admin_login)

def admin_logout(request):

    if "admin_name" in request.COOKIES and request.session.has_key('admin_name'):
        
        del request.session['admin_name']
        del request.session['admin_email']
        
        response = redirect(admin_login)
        response.delete_cookie('admin_name')
        response.delete_cookie('admin_email')
        return response
    
    else:
        return redirect(admin_login)

####################################################################################################################################################################################
# PRODUCT TABLE

def product_form(request):
    
    if 'admin_name' in request.COOKIES and request.session.has_key('admin_name'):

        if Category.objects.exists():
            categories = Category.objects.all()
        
        if request.method == "POST":
            if not Product.objects.filter(product_name = request.POST.get("product_name"), product_price = request.POST.get("product_price")):
                Product.objects.create(**postquery(request.POST, request.FILES, categories))
                
        return render(request, "admin_panel/product/add-product.html", {"categories": categories})
    else:
        return redirect(admin_login)

def product_update(request, id):
    
    if 'admin_name' in request.COOKIES and request.session.has_key('admin_name'):
        
        dataset = Product.objects.filter(id = id)
    
        if Category.objects.exists():
            categories = Category.objects.all()
        
        if request.method == "POST":
            
            dataset.update(**postquery(request.POST, None, categories))
            
            dataset = Product.objects.get(id = id)
            dataset.product_image = request.FILES['product_image']
            dataset.save()
        
            return redirect(products_display)
        
        return render(request, "admin_panel/product/update-product.html", {"data": dataset, "categories": categories})

    else:
        return redirect(admin_login)
    
    

def product_delete(request, id):
    
    if 'admin_name' in request.COOKIES and request.session.has_key('admin_name'):
    
        dataset = Product.objects.filter(id = id)
        
        if dataset is not None:
            dataset.delete()
            
        return redirect(products_display)

    else:
        return redirect(admin_login)


def products_display(request):
    
    if 'admin_name' in request.COOKIES and request.session.has_key('admin_name'):
        
        dataset = {}
        
        if Product.objects.exists():
            dataset = Product.objects.all()
            # print(dataset.values_list())

        return render(request, "admin_panel/product/display-products.html", {"data": dataset.values()})

    else:
        return redirect(admin_login)

####################################################################################################################################################################################
# CATEGORY TABLE

def category_form(request):
    
    if 'admin_name' in request.COOKIES and request.session.has_key('admin_name'):
    
        if request.method == "POST":
            category_name = request.POST.get("category_name")

            if not Category.objects.filter(category_name = category_name):
                Category.objects.create(category_name = category_name)
                
            return redirect(category_form)   
        return render(request, "admin_panel/category/add-category.html")
    
    else:
        return redirect(admin_login)

def category_update(request, id):
    
    if 'admin_name' in request.COOKIES and request.session.has_key('admin_name'):
    
        dataset = Category.objects.filter(id = id)
        
        if request.method == "POST":
            dataset.update(category_name = request.POST.get("category_name")) 
            return redirect(categories_display)
        
        return render(request, "admin_panel/category/update-category.html", {"data": dataset})
    else:
        return redirect(admin_login)

def category_delete(request, id):
    
    if 'admin_name' in request.COOKIES and request.session.has_key('admin_name'):
        dataset = Category.objects.filter(id = id)
        
        if dataset is not None:
            dataset.delete()
            
        return redirect(categories_display)
    else:
        return redirect(admin_login)
       
def categories_display(request):
    
    if 'admin_name' in request.COOKIES and request.session.has_key('admin_name'):
        dataset = {}
        
        if Category.objects.exists():
            dataset = Category.objects.all()
            print(dataset.values_list())
            
        return render(request, "admin_panel/category/display-categories.html", {"data": dataset.values()})
    else:
        return redirect(admin_login)

####################################################################################################################################################################################
# CONTACT TABLE

def contact_form(request):
    
    if 'admin_name' in request.COOKIES and request.session.has_key('admin_name'):
        
        if request.method == "POST":
            Contact.objects.create(**postquery(request.POST))
            return redirect(contact_form)
        
        return render(request, "admin_panel/contact/add-contact.html")
    else:
        return redirect(admin_login)

def contact_update(request, id):
    
    if 'admin_name' in request.COOKIES and request.session.has_key('admin_name'):
        dataset = Contact.objects.filter(id = id)
        
        if request.method == "POST":
            dataset.update(**postquery(request.POST))
            return redirect(contacts_display)
        
        return render(request, "admin_panel/contact/update-contact.html", {"data": dataset})
    else:
        return redirect(admin_login)
    
def contact_delete(request, id):
    if 'admin_name' in request.COOKIES and request.session.has_key('admin_name'):
    
        dataset = Contact.objects.filter(id = id)
        
        if dataset is not None:
            dataset.delete()
            
        return redirect(contacts_display)
    else:
        return redirect(admin_login)   
    
def contacts_display(request):
    
    if 'admin_name' in request.COOKIES and request.session.has_key('admin_name'):
    
        dataset = {}
        
        if Category.objects.exists():
            dataset = Contact.objects.all()
            
        return render(request, "admin_panel/contact/display-contacts.html", {"data": dataset.values()})
    else:
        return redirect(admin_login)
    
####################################################################################################################################################################################
# ORDER TABLE

def order_form(request):

    if not ("admin_name" in request.COOKIES and request.session.has_key('admin_name')):
        return redirect(admin_login)
    
    if User.objects.exists():
        users = User.objects.all()
    
    if request.method == "POST":    
        Order.objects.create(**postquery(request.POST, None, users))
            
    return render(request, "admin_panel/order/add-order.html", {"users": users})

def order_update(request, id):
    
    if not ("admin_name" in request.COOKIES and request.session.has_key('admin_name')):
        return redirect(admin_login)
    
    dataset = Order.objects.filter(id = id)
    
    if User.objects.exists():
        users = User.objects.all()
    
    if request.method == "POST":
        dataset.update(**postquery(request.POST, None, users))
        return redirect(orders_display)
       
    return render(request, "admin_panel/order/update-order.html", {"data": dataset, "users": users})

def order_delete(request, id):
    
    if not ("admin_name" in request.COOKIES and request.session.has_key('admin_name')):
        return redirect(admin_login)
    
    dataset = Order.objects.filter(id = id)
    
    if dataset is not None:
        dataset.delete()
        
    return redirect(orders_display)

def orders_display(request):
    
    if not ("admin_name" in request.COOKIES and request.session.has_key('admin_name')):
        return redirect(admin_login)
    
    dataset = {}
    
    if Order.objects.exists():
        dataset = Order.objects.all()

    return render(request, "admin_panel/order/display-orders.html", {"data": dataset.values()})

####################################################################################################################################################################################
# ORDER DETAILS TABLE

def order_details_form(request):
    
    if not ("admin_name" in request.COOKIES and request.session.has_key('admin_name')):
        return redirect(admin_login)
    
    if Order.objects.exists():
        orders = Order.objects.all()
        
    if Product.objects.exists():
        products = Product.objects.all()
    
    if request.method == "POST":
        OrderDetails.objects.create(**postquery(request.POST, None, [orders, products]))
        
    return render(request, "admin_panel/order_details/add-orderdetails.html", {"orders": orders, "products": products})


def order_details_update(request, id):
    
    if not ("admin_name" in request.COOKIES and request.session.has_key('admin_name')):
        return redirect(admin_login)
    
    dataset = OrderDetails.objects.filter(id = id)
    
    if Order.objects.exists():
        orders = Order.objects.all()
        
    if Product.objects.exists():
        products = Product.objects.all()
    
    if request.method == "POST":
        dataset.update(**postquery(request.POST, None, [orders, products]))
        return redirect(orders_details_display)
       
    return render(request, "admin_panel/order_details/update-orderdetails.html", {"data": dataset, "orders": orders, "products": products})

def order_details_delete(request, id):
    
    if not ("admin_name" in request.COOKIES and request.session.has_key('admin_name')):
        return redirect(admin_login)
    
    dataset = OrderDetails.objects.filter(id = id)
    
    if dataset is not None:
        dataset.delete()
        
    return redirect(orders_details_display)

def orders_details_display(request):
    
    if not ("admin_name" in request.COOKIES and request.session.has_key('admin_name')):
        return redirect(admin_login)
    
    dataset = {}
    
    if OrderDetails.objects.exists():
        dataset = OrderDetails.objects.all()

    return render(request, "admin_panel/order_details/display-orderdetails.html", {"data": dataset.values()})

####################################################################################################################################################################################
# USER TABLE

def user_form(request):
    
    if not ("admin_name" in request.COOKIES and request.session.has_key('admin_name')):
        return redirect(admin_login)
    
    if request.method == "POST":
        
        if not User.objects.filter(user_email = request.POST.get("user_email")):
            User.objects.create(**postquery(request.POST))
        return redirect(user_form)
    
    return render(request, "admin_panel/user/add-user.html")

def user_update(request, id):
    
    if not ("admin_name" in request.COOKIES and request.session.has_key('admin_name')):
        return redirect(admin_login)
    
    dataset = User.objects.filter(id = id)
    
    if request.method == "POST":
        dataset.update(**postquery(request.POST))
        return redirect(users_display)
       
    return render(request, "admin_panel/user/update-user.html", {"data": dataset})

def user_delete(request, id):
    
    if not ("admin_name" in request.COOKIES and request.session.has_key('admin_name')):
        return redirect(admin_login)
    
    dataset = User.objects.filter(id = id)
    
    if dataset is not None:
        dataset.delete()
        
    return redirect(users_display)
       
def users_display(request):
    
    if not ("admin_name" in request.COOKIES and request.session.has_key('admin_name')):
        return redirect(admin_login)
    
    dataset = {}
    
    if User.objects.exists():
        dataset = User.objects.all()
        
    return render(request, "admin_panel/user/display-users.html", {"data": dataset.values()})

####################################################################################################################################################################################
# FEEDBACK TABLE

def feedback_form(request):
    
    if not ("admin_name" in request.COOKIES and request.session.has_key('admin_name')):
        return redirect(admin_login)
    
    if User.objects.exists():
        users = User.objects.all()
    
    if request.method == "POST":    
        Feedback.objects.create(**postquery(request.POST, None, users))
            
    return render(request, "admin_panel/feedback/add-feedback.html", {"users": users})

def feedback_update(request, id):
    
    if not ("admin_name" in request.COOKIES and request.session.has_key('admin_name')):
        return redirect(admin_login)
    
    dataset = Feedback.objects.filter(id = id)
    
    if User.objects.exists():
        users = User.objects.all()
    
    if request.method == "POST":
        dataset.update(**postquery(request.POST, None, users))
        return redirect(feedbacks_display)
       
    return render(request, "admin_panel/feedback/update-feedback.html", {"data": dataset, "users": users})

def feedback_delete(request, id):
    
    if not ("admin_name" in request.COOKIES and request.session.has_key('admin_name')):
        return redirect(admin_login)
    
    dataset = Feedback.objects.filter(id = id)
    
    if dataset is not None:
        dataset.delete()
        
    return redirect(feedbacks_display)

def feedbacks_display(request):
    
    if not ("admin_name" in request.COOKIES and request.session.has_key('admin_name')):
        return redirect(admin_login)
    
    dataset = {}
    
    if Feedback.objects.exists():
        dataset = Feedback.objects.all()

    return render(request, "admin_panel/feedback/display-feedbacks.html", {"data": dataset.values()})

####################################################################################################################################################################################

def login_page(request):
    return render(request, "admin_panel/user/login.html")

def display(request):
    return render(request, "admin_panel/tables.html")


