from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from .views import *

urlpatterns = [
    
    path("", form, name="form"),
    
    path("admin-signup", admin_signup, name="add_admin"),
    path("admin-update-profile/<id>", admin_update, name="update_admin"),
    path("delete-admin/<id>", admin_delete, name="delete_admin"),
    path("admin-profile", admins_display, name="display_admin"),
    path("admin-login", admin_login, name="admin_login"),
    path("admin-logout", admin_logout, name="admin_logout"),
    path("admin-change-password", admin_change_password, name="admin_change_password"),
    
    path("add-product", product_form, name="add_product"),
    path("update-product/<id>", product_update, name="update_product"),
    path("delete-product/<id>", product_delete, name="delete_product"),
    path("display-product", products_display, name="display_product"),
    
    path("add-category", category_form, name="add_category"),
    path("update-category/<id>", category_update, name="update_category"),
    path("delete-category/<id>", category_delete, name="delete_category"),
    path("display-category", categories_display, name="display_category"),
    
    path("add-contact", contact_form, name="add_contact"),
    path("update-contact/<id>", contact_update, name="update_contact"),
    path("delete-contact/<id>", contact_delete, name="delete_contact"),
    path("display-contact", contacts_display, name="display_contact"),
    
    path("add-order", order_form, name="add_order"),
    path("update-order/<id>", order_update, name="update_order"),
    path("delete-order/<id>", order_delete, name="delete_order"),
    path("display-order", orders_display, name="display_order"),
        
    path("add-order-details", order_details_form, name="add_order_details"),
    path("update-order-details/<id>", order_details_update, name="update_order_details"),
    path("delete-order-details/<id>", order_details_delete, name="delete_order_details"),
    path("display-order-details", orders_details_display, name="display_order_details"),
    
    path("add-user", user_form, name="add_user"),
    path("update-user/<id>", user_update, name="update_user"),
    path("delete-user/<id>", user_delete, name="delete_user"),
    path("display-user", users_display, name="display_user"),
    
    path("add-feedback", feedback_form, name="add_feedback"),
    path("update-feedback/<id>", feedback_update, name="update_feedback"),
    path("delete-feedback/<id>", feedback_delete, name="delete_feedback"),
    path("display-feedback", feedbacks_display, name="display_feedback"),
    
    path("dashboard", dashboard, name="dashboard"),
    path("dashboard-update/<id>/<status>", dashboard_update, name="dashboard_update"),
    path("dashboard-delete/<id>", dashboard_delete, name="dashboard_delete"),
    
    path("login", login_page, name="login"),
    path("display", display, name="display"),  
    
] + static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)