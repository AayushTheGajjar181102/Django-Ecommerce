from django.db import models
from django.conf import settings
# Create your models here.

class Admin(models.Model):
    admin_name = models.CharField(max_length=50)
    admin_email = models.EmailField()
    admin_password = models.TextField()
    
class User(models.Model):
    user_name = models.CharField(max_length=50)
    user_gender = models.CharField(max_length=10)
    user_email = models.EmailField()
    user_password = models.CharField(max_length=50)
    user_mobile = models.DecimalField(max_digits=10, decimal_places=0)
    user_address = models.TextField()
    
class Category(models.Model):
    category_name = models.CharField(max_length=50)
    
    # def __str__(self) -> str:
    #     return self.category_name

class Product(models.Model):
    product_name = models.CharField(max_length=50)
    product_detail = models.TextField()
    product_price = models.DecimalField(max_digits=10, decimal_places=2)
    product_image = models.ImageField(upload_to= "products/")
    product_quantity = models.IntegerField(default=1)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, default=None)
    
class Contact(models.Model):
    contact_name = models.CharField(max_length=50)
    contact_subject = models.CharField(max_length=400)
    contact_detail = models.TextField()
    
class Order(models.Model):
    order_date = models.DateField()
    shipping_name = models.CharField(max_length=100)
    shipping_email = models.EmailField()
    shipping_mobile = models.DecimalField(max_digits=10, decimal_places=0)
    shipping_address = models.TextField(null=True)
    payment_method = models.CharField(max_length=50)
    payment_before_tax = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    payment_tax = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    payment_after_tax = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    status = models.CharField(max_length=50, default="Not Delivered")
    razorpay_order_id = models.CharField(max_length=100, null=True, blank=True)
    razorpay_payment_id = models.CharField(max_length=100, null=True, blank=True)
    razorpay_order_signature = models.CharField(max_length=100, null=True, blank=True)
    is_paid = models.BooleanField(default=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, default=None)
    
class OrderDetails(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, default=None)
    product = models.ForeignKey(Product, on_delete=models.CASCADE, default=None)
    quantity = models.IntegerField()
    status = models.CharField(max_length=50, default="Not Delivered")
    order_price = models.DecimalField(max_digits=10, decimal_places=2)

class Todo(models.Model):
    task = models.TextField()
    status = models.CharField(max_length=100, default='Pending')
    admin = models.ForeignKey(Admin, on_delete=models.CASCADE)
    
class Feedback(models.Model):
    feedback_date = models.DateField(auto_now=True)
    feedback_details = models.TextField()
    user = models.ForeignKey(User, on_delete=models.CASCADE)